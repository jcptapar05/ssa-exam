import React from "react";
import Title from "./Title";

const Meet = () => {
  return (
    <div className="container text-center meet">
      <div>
        <Title name="Meet Protoapp" titleColor="black" />
        <p>The lorem ipsum is common placeholder text used to demonstrate the graphic elements of a document or visual presentation.</p>
      </div>
    </div>
  );
};

export default Meet;
