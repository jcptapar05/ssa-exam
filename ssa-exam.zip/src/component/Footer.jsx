import React from "react";

const Footer = () => {
  return (
    <div className="container-fluid footer">
      <div className="container text-white">
        <p>&copy; 2019 Protoapp. All right reserved.</p>
      </div>
    </div>
  );
};

export default Footer;
